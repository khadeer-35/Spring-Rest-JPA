# Spring-REST-JPA
Springboot application with JPA /Hibernate and REST
